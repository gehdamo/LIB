let RECOMbook = document.querySelector('.RECOMbook');

let cheerio = require('cheerio');
let request = require('request');

let RECOMbookurl = "https://janghowon-m.goeic.kr/bbs/board.do?bsIdx=3746&menuId=8429#1";


var url = "https://www.naver.com/";

request(url, function(error, response, html){
    if (error) {throw error};

    console.log(html);
});
